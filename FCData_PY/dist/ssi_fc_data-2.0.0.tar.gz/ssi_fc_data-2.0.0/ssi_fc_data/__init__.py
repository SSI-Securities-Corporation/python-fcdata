# This is a property
# of SSI company

import warnings
warnings.filterwarnings("ignore")
from .model import model
from . import fc_md_client
from . import fc_md_stream

name = "ssi_fc_data"
version = "2.0.0"



